# -*- coding: utf-8 -*-
# type: ignore
# Ignore the type hinting for this file, because we are using dynamic method creation
# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2023-01-11
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#


from __future__ import annotations
from typing import Any
from requests import Session
from rest_api_client_core.rest_api_endpoint_registry import RestApiEndpointRegistry

# Make MyPy ignore this type, because we dynamically add methods to this class
# and MyPy does not understand this.

# noinspection PyPep8Naming


class RestApiClientCore:
    """
    Represents the core REST API client.

    This class provides methods for managing the REST API client session, updating the session, closing the session,
    retrieving attributes from the registry, and serving as a context manager.

    Attributes:
        _session (Session): The session object used by the REST API client.
        _registry (RestApiEndpointRegistry): The registry containing the REST API endpoints.

    Methods:
        __init__(self, registry: RestApiEndpointRegistry) -> None:
            Initializes a new instance of the RestApiClientCore class.

        Update(self) -> None:
            Updates the session of the REST API client.

        close(self) -> None:
            Closes the session used by the REST API client.

        __getattr__(self, name: str) -> Any:
            Retrieves the attribute specified by the given name.

        __enter__(self) -> RestApiClientCore:
            Context manager entry point.

        __exit__(self, exc_type, exc_value, traceback) -> None:
            Exit the context manager and perform necessary cleanup.
    """

    def __init__(self, registry: RestApiEndpointRegistry) -> None:
        """
        Initializes a new instance of the RestApiClientCore class.

        Args:
            registry (RestApiEndpointRegistry): The registry containing the REST API endpoints.

        Returns:
            None
        """
        self._session: Session = Session()
        self._registry: RestApiEndpointRegistry = registry

        self.Update()

    def Update(self) -> None:
        """
        Updates the session of the REST API client.

        This method sets the session of the REST API client to the provided session object.

        Parameters:
            None

        Returns:
            None
        """
        self._registry.session = self._session

    def close(self) -> None:
        """
        Closes the session used by the REST API client.
        """
        if self._session:
            self._session.close()

    def __getattr__(self, name: str) -> Any:
        """
        Retrieves the attribute specified by the given name.

        This method is called when an attribute is accessed that is not directly defined in the class.
        It checks if the attribute name exists in the registry and returns the corresponding ApiEndpointCallMethod.

        Args:
            name (str): The name of the attribute to retrieve.

        Returns:
            Any: The ApiEndpointCallMethod associated with the attribute name.

        Raises:
            AttributeError: If the attribute name is not found in the registry.
        """
        if name in self._registry:
            return self._registry[name].ApiEndpointCallMethod
        else:
            raise AttributeError(f"Attribute {name} not found")

    def __enter__(self) -> RestApiClientCore:
        """
        Context manager entry point.

        Returns:
            RestApiClientCore: The current instance of the RestApiClientCore class.
        """
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """Exit the context manager and perform necessary cleanup.

        This method is automatically called when exiting the context manager.
        It closes the session, clears the registry, and updates the state.

        Arguments:
            exc_type (type): The type of the exception raised, if any.
            exc_value (Exception): The exception instance raised, if any.
            traceback (traceback): The traceback object associated with the exception, if any.
        """
        self.close()
        self._session = None
        self._registry = None
        self.Update()
