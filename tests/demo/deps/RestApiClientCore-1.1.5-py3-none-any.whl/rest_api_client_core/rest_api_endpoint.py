# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2023-01-11
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#


from typing import Any, Dict, Optional, Callable
from requests import Session
import os
from rest_api_client_core.rest_api_response_parser_base import RestApiResponseParserBase


class RestApiEndpoint:
    """
    Represents a REST API endpoint.

    Args:
        session (Session): The session object used for making API requests.
        base_url (str): The base URL of the API.
        method (str): The HTTP method to be used for the API request.
        api_endpoint (str): The endpoint of the API.
        api_request (Callable): The function used for making the API request.
        response_parser (RestApiResponseParserBase): The response parser object used for parsing the API response.
        raw (Optional[bool], optional): Flag indicating whether to use raw URL or not. Defaults to False.
        headers (Optional[Dict[str, dict]], optional): Custom headers for the API request. Defaults to None.

    Attributes:
        session (Session): The session object used for making API requests.
        base_url (str): The base URL of the API.
        method (str): The HTTP method to be used for the API request.
        api_endpoint (str): The endpoint of the API.
        api_request (Callable): The function used for making the API request.
        response_parser (RestApiResponseParserBase): The response parser object used for parsing the API response.
        raw (bool): Flag indicating whether to use raw URL or not.
        headers (Dict[str, dict]): The headers for the API request.

    Methods:
        _ExpandUrlData(url: str, url_data: Optional[str]) -> str:
            Expands the URL with the provided URL data.
        GetHeaders(auth: str, match: Optional[str] = None) -> dict:
            Returns the headers for the API request.
        ApiEndpointCallMethod(auth: str, data: Optional[str] = None, query_params: Optional[dict] = None, url_data: Optional[str] = None, **kwargs) -> Any:
            Makes the API request and returns the decoded response.

    """

    def __init__(
        self,
        session: Session,
        base_url: str,
        method: str,
        api_endpoint: str,
        api_request: Callable,
        response_parser: RestApiResponseParserBase,
        raw: Optional[bool] = False,
        headers: Optional[Dict[str, dict]] = None,
        requires_auth: bool = True,
    ) -> None:
        """
        Initializes a RestApiEndpoint object.
        Args:
            session (Session): The session object used for making HTTP requests.
            base_url (str): The base URL of the API.
            method (str): The HTTP method to be used for the API request.
            api_endpoint (str): The endpoint of the API.
            api_request (Callable): The function that will be used to make the API request.
            response_parser (RestApiResponseParserBase): The response parser object used to parse the API response.
            raw (bool, optional): Flag indicating whether to return the raw response or parse it. Defaults to False.
            headers (Dict[str, dict], optional): Custom headers to be included in the API request. Defaults to None.
        """
        self.session: Session = session
        self.base_url: str = base_url
        self.method: str = method
        self.api_endpoint: str = api_endpoint
        self.api_request: Callable = api_request
        self.response_parser: RestApiResponseParserBase = response_parser
        self.raw: bool = raw
        self.headers: dict[str, dict] = {
            "GET": {"Accept": "application/json"},
            "DELETE": {"Accept": "application/json"},
            "POST": {
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            "PUT": {
                "Accept": "application/json",
                "If-Match": "*",
                "Content-Type": "application/json",
            },
        }
        if headers is not None:
            self.headers.update(headers)
        self.requires_auth: bool = requires_auth

    @staticmethod
    def _ExpandUrlData(url: str, url_data: Optional[str]) -> str:
        """
        Expands the URL with the provided URL data.

        Args:
            url (str): The base URL.
            url_data (Optional[str]): The URL data to be appended to the base URL.

        Returns:
            str: The expanded URL.

        """
        if not url_data:
            return url
        return f"{url}/{url_data}"

    def GetHeaders(self, auth: str, match: Optional[str] = None) -> dict:
        """
        Returns the headers for the REST API request.

        Args:
            auth (str): The authentication token.
            match (str, optional): The match value for the If-Match header.

        Returns:
            dict: The headers for the REST API request.
        """
        hdr: dict = self.headers[self.method].copy()
        if self.requires_auth is True:
            hdr["Authorization"] = f"Bearer {auth}"
        if match is not None:
            hdr.update({"If-Match": match})
        return hdr

    def ApiEndpointCallMethod(
        self,
        auth: str,
        data: Optional[str] = None,
        query_params: Optional[dict] = None,
        url_data: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """
        Makes a call to the API endpoint.

        Args:
            auth (str): The authentication token.
            data (str, optional): The data to send in the request body. Defaults to None.
            query_params (dict, optional): The query parameters to include in the request. Defaults to None.
            url_data (str, optional): The URL data to include in the request URL. Defaults to None.
            **kwargs: Additional keyword arguments to pass to the API request.

        Returns:
            Any: The decoded response from the API.

        Raises:
            Exception: If an error occurs during the API request or response parsing.

        """
        url = self._ExpandUrlData(f"{self.base_url}{self.api_endpoint}", url_data)
        if self.raw and url_data is not None:
            url = url_data
        try:
            headers = self.GetHeaders(auth=auth)
            if "headers" in kwargs:
                headers.update(kwargs.get("headers"))
            match = None
            if "match" in kwargs:
                match = kwargs.pop("match")
            response = self.api_request(
                session=self.session,
                method=self.method,
                url=url,
                auth=auth,
                data=data,
                headers=self.GetHeaders(auth=auth, match=match),
                params=query_params,
                requirest_auth=self.requires_auth,
                **kwargs,
            )
        except Exception as ex:
            print(f"ApiEndpointCall Exception: {ex}")
            os._exit(1)
        try:
            decoded = self.response_parser.ParseResponse(response)
            return decoded
        except Exception as ex:
            print(f"ApiEndpointCall Exception: {ex}")
            os._exit(1)
