# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2023-01-11
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#

from requests import Session, Response
import sys


def RestApiRequest(
    session: Session,
    method: str,
    url: str,
    auth: str,
    headers: dict[str, str],
    verify: bool = True,
    exit_on_not_200: bool = False,
    params: dict = {},
    requirest_auth: bool = True,
    **kwargs,
) -> Response:
    """
    Sends a REST API request using the provided session object.

    Args:
        session (Session): The session object to use for making the request.
        method (str): The HTTP method to use for the request (e.g., GET, POST, PUT, DELETE, etc.).
        url (str): The URL to send the request to.
        auth (str): The authentication token to include in the request headers.
        headers (dict[str, str]): The headers to include in the request.
        verify (bool, optional): Whether to verify the SSL certificate. Defaults to True.
        exit_on_not_200 (bool, optional): Whether to exit the program if the response status code is not 200. Defaults to False.
        params (dict, optional): The query parameters to include in the request. Defaults to {}.
        **kwargs: Additional keyword arguments to pass to the underlying session request method.

    Returns:
        Response: The response object returned by the request.

    Raises:
        Exception: If any of the required arguments (method, url, auth, headers) are not provided.
        ValueError: If the provided method is not supported.

    Note:
        This function supports the following HTTP methods: GET, POST, PUT, DELETE, PATCH, OPTIONS, HEAD.
    """

    if not method:
        raise Exception("No method provided")
    if not url:
        raise Exception("No url provided")
    if not auth and requirest_auth:
        raise Exception("No authentication token provided")
    if not headers:
        raise Exception("No headers provided")

    if not "allow_redirects" in kwargs:
        kwargs["allow_redirects"] = True

    # for debugging uncomment the next lines
    # print(f"Method:  {method}")
    # print(f"URL:     {url}")
    # print(f"Headers: {headers}")
    # print(f"Params:  {params}")
    # print(f"Kwargs:  {kwargs}")
    # print()

    try:
        if method == "GET":
            response = session.get(
                url, headers=headers, verify=verify, params=params, **kwargs
            )
        elif method == "DELETE":
            response = session.delete(
                url, headers=headers, verify=verify, params=params, **kwargs
            )
        elif method == "POST":
            response = session.post(
                url, headers=headers, verify=verify, params=params, **kwargs
            )
        elif method == "PUT":
            response = session.put(
                url, headers=headers, verify=verify, params=params, **kwargs
            )
        elif method == "PATCH":
            response = session.patch(url, headers=headers, verify=verify, **kwargs)
        elif method == "OPTIONS":
            response = session.options(url, headers=headers, verify=verify, **kwargs)
        elif method == "HEAD":
            response = session.head(url, headers=headers, verify=verify, **kwargs)
        else:
            print(f"RestApiRequest: Method {method} not supported")
            sys.exit(1)
    except Exception as ex:
        # print()
        # print("RestApiRequest Exception")
        # print()
        # print(f"Response code: {response.status_code if response else 'None'}")
        # print(f"Response text: {response.text if response else 'None'}")
        # print()
        # print("The exception:")
        print(f"RestApiRequest: Exception: {ex}")
        sys.exit(1)
    try:
        if (
            response is not None
            and response.status_code != 200
            and exit_on_not_200 is True
        ):
            print(f"Response status code: {response.status_code}")
            print(response.text)
            sys.exit(1)
    except:
        # catch it when response.status_code is not available
        # then we can pass and just pass the raw response
        pass
    return response
