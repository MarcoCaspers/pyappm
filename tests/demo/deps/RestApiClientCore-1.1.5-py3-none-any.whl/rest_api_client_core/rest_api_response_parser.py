# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2023-01-11
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#


import json
from typing import Any, Optional
from rest_api_client_core.rest_api_response_parser_base import RestApiResponseParserBase
from rest_api_client_core.rest_api_response_object import RestApiResponseObject


class RestApiResponseParser(RestApiResponseParserBase):
    """
    A class for parsing REST API responses.

    This class provides methods to parse a response text into a structured object.

    Attributes:
        None

    Methods:
        ParseResponse: Parses the response text and returns the parsed object.

    """

    def __init__(self) -> None:
        pass

    def ParseResponse(self, response_text: str) -> Any:
        """
        Parses the response text and returns the parsed object.

        Args:
            response_text (str): The response text to be parsed.

        Returns:
            Any: The parsed object.

        """
        try:
            data = json.loads(response_text)
            return self._ParseObject(data)
        except Exception as ex:
            print(f"ParseResponse Exception: {ex}")

    def _ParseObject(
        self, data: dict, obj_type: Optional[RestApiResponseObject] = None
    ) -> Any:
        """
        Parses the data dictionary and returns the parsed object.

        Args:
            data (dict): The data dictionary to be parsed.
            obj_type (Optional[RestApiResponseObject]): The object type to be used for parsing.

        Returns:
            Any: The parsed object.

        Raises:
            Exception: If the input data type is not supported.

        """
        if obj_type is None:
            obj_type = RestApiResponseObject()

        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    setattr(obj_type, key, self._ParseObject(value))
                elif isinstance(value, list):
                    lst = []
                    for item in value:
                        lst.append(self._ParseObject(item))
                    setattr(obj_type, key, lst)
                else:
                    setattr(obj_type, key, value)
        else:
            raise Exception(f"Can't handle input data type: {type(data)}")

        return obj_type
