# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2023-01-11
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#


# Plain text response parser

from typing import Any, Union, Optional
from rest_api_client_core.rest_api_response_parser_base import RestApiResponseParserBase
from rest_api_client_core.rest_api_response_object import RestApiResponseObject


class RestApiPlainTextResponseParser(RestApiResponseParserBase):
    """
    A class that parses plain text responses from a REST API.

    This class provides methods to parse the response text and construct a RestApiResponseObject.

    Attributes:
        None

    Methods:
        ParseResponse: Parses the response text and returns the parsed object.
        _ParseObject: Parses the input data and constructs a RestApiResponseObject.
    """

    def ParseResponse(self, response_text: str) -> Any:
        """
        Parses the response text and returns the parsed object.

        Args:
            response_text (str): The response text to be parsed.

        Returns:
            Any: The parsed object.

        Raises:
            Exception: If an error occurs while parsing the response text.
        """
        try:
            return self._ParseObject(response_text)
        except Exception as ex:
            print(f"ParseResponse Exception: {ex}")

    def _ParseObject(
        self, data: Union[dict, str], obj_type: Optional[RestApiResponseObject] = None
    ) -> Any:
        """
        Parses the input data and constructs a RestApiResponseObject.

        Args:
            data (Union[dict, str]): The input data to be parsed.
            obj_type (Optional[RestApiResponseObject]): The object type to be constructed. If None, a new RestApiResponseObject will be created.

        Returns:
            Any: The constructed RestApiResponseObject.

        Raises:
            Exception: If the input data type is not supported.
        """
        if obj_type is None:
            obj_type = RestApiResponseObject()

        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    setattr(obj_type, key, self._ParseObject(value))
                elif isinstance(value, list):
                    lst = []
                    for item in value:
                        lst.append(self._ParseObject(item))
                    setattr(obj_type, key, lst)
                else:
                    setattr(obj_type, key, value)
        elif isinstance(data, str):
            setattr(obj_type, "text", data)
        else:
            raise Exception(f"Can't handle input data type: {type(data)}")

        return obj_type
