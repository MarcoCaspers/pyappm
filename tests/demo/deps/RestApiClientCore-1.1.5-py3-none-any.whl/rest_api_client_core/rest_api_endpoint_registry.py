# -*- coding: utf-8 -*-
#
# Product:   REST API Client Core
# Author:    Marco Caspers
# Email:     SamaDevTeam@westcon.com
# License:   MIT License
# Date:      2024-02-26
#
# Copyright 2024 Westcon-Comstor
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.
#
# SPDX-License-Identifier: MIT
#

# Rest API Endpoint Registry

from typing import Optional, Callable
from requests import Session
from rest_api_client_core.rest_api_endpoint import RestApiEndpoint
from rest_api_client_core.rest_api_response_parser_base import RestApiResponseParserBase


class RestApiEndpointRegistry:
    def __init__(
        self,
        base_url: str,
        api_request: Callable,
        response_parser: RestApiResponseParserBase,
    ) -> None:
        """
        Initialize a RestApiEndpointRegistry object.

        Arguments:
            base_url (str): The base URL of the REST API.
            api_request (Callable): A callable object used to make API requests.
            response_parser (RestApiResponseParserBase): An object responsible for parsing API responses.
        """
        self._registry: dict[str, RestApiEndpoint] = {}
        self.session: Optional[Session] = None
        self.base_url: str = base_url
        self.api_request = api_request
        self.response_parser = response_parser

    def RegisterRestApiEndpoint(
        self,
        name: str,
        method: str,
        api_endpoint: str,
        raw: Optional[bool] = False,
        headers: Optional[dict[str, dict]] = None,
        requirest_auth: bool = True,
    ) -> None:
        """
        Register a REST API endpoint.

        Args:
            name (str): The name of the endpoint.
            method (str): The HTTP method for the endpoint (e.g., GET, POST, PUT, DELETE).
            api_endpoint (str): The API endpoint URL.
            raw (bool, optional): Whether to return the raw response. Defaults to False.
            headers (dict[str, dict], optional): Additional headers to include in the request. Defaults to None.

        Raises:
            ValueError: If the session is not set.

        Returns:
            None
        """
        if self.session is None:
            raise ValueError("RegisterRestApiEndpoint: Session is not set")
        endpoint = RestApiEndpoint(
            session=self.session,
            base_url=self.base_url,
            method=method,
            api_endpoint=api_endpoint,
            api_request=self.api_request,
            response_parser=self.response_parser,
            raw=raw,
            headers=headers,
            requires_auth=requirest_auth,
        )
        self._registry[name] = endpoint

    def __getitem__(self, name: str) -> RestApiEndpoint:
        """
        Get the RestApiEndpoint object associated with the given name.
        Args:
            name (str): The name of the endpoint.
        Returns:
            RestApiEndpoint: The RestApiEndpoint object associated with the given name.
        Raises:
            KeyError: If the name is not found in the registry.
        """
        return self._registry[name]

    def __contains__(self, name: str) -> bool:
        """
        Check if the given name is present in the registry.

        Args:
            name (str): The name to check.

        Returns:
            bool: True if the name is present in the registry, False otherwise.
        """
        return name in self._registry

    def __iter__(self):
        """
        Returns an iterator for the registry.
        """
        return iter(self._registry)

    def __len__(self) -> int:
        """
        Returns the number of items in the registry.

        :return: The number of items in the registry.
        :rtype: int
        """
        return len(self._registry)

    def items(self) -> dict[str, RestApiEndpoint]:
        """
        Returns a dictionary containing all the registered REST API endpoints.

        Returns:
            A dictionary where the keys are the endpoint names and the values are the corresponding RestApiEndpoint objects.
        """
        return dict(self._registry.items())

    def GetItems(self) -> dict[str, RestApiEndpoint]:
        """
        Retrieves all the registered REST API endpoints.
        Returns:
            A dictionary containing the registered REST API endpoints.
        """
        return dict(self._registry.items())
